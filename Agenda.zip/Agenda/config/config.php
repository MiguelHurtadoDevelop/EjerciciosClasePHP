<?php

define('SERVIDOR', 'localhost');
define('USUARIO', 'root');
define('PASSWORD', '');
define('BASE_DATOS', 'agenda');

define('BASE_URL', 'index.php');

define('CONTROLLER_DEFAULT', 'ContactoController');
define('ACTION_DEFAULT', 'showAll');
<form action="#" method="post">
    <a href=<?= BASE_URL?>>Cancelar</a>

    <p>
        <label>Nombre</label>
        <input type="text">
    </p>
    <p>
        <label>Apellidos</label>
        <input type="text">
    </p>
    <p>
        <label>Teléfono</label>
        <input type="text">
    </p>
    <p>
        <label>Correo</label>
        <input type="text">
    </p>
</form>

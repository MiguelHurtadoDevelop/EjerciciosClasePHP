<?php
    require_once("autoLoad.php");
    require_once('./config/config.php');

    require_once ("Views/Layout/header.html");
    use Lib\BaseDatos;
    use Lib\Pages;
require_once ("Views/Layout/footer.html");
?>